# 综合数据摘录表模板

> 综合完成后报告通常含 19 个文件。撰写报告、制作汇报材料或与协作方核对数据时，所需的是一张汇总表，
> 而非逐一翻查 19 份文件。本表填写一次，后续所有引用均以本表为准。

## 一、填表前的两项确认

| # | 操作 | 原因 |
|---|---|---|
| 1 | 确认报告出自**当前源码** | 以 `scripts/loop_id_consistency.py` 核对。引用旧代码的报告时，全部数值失效（见 `K10`） |
| 2 | 确认 `Target device` 为目标器件 | 日志混入默认器件时，数值全部不可用（本工程 15 次运行中前 11 次为 `xcvu5p`） |

## 二、单 IP 数据表（HLS 估计）

| 项 | 值 | 出处（文件:行） |
|---|---|---|
| 器件 |  | `*_csynth.rpt` General Information |
| 约束周期 | ns | 同上，Timing 表 Target |
| 估计周期 | ns | 同上，Timing 表 Estimated |
| 估计 Fmax | MHz | `1000 / 估计周期` |
| BRAM_18K |  | Utilization 表 **Total 行** |
| DSP |  | 同上 |
| FF |  | 同上 |
| LUT |  | 同上 |
| Latency min | 拍 | Performance 表 |
| Latency max | 拍 | 同上 |
| Latency Type | dataflow / no | 同上，**这是并行化的唯一硬证据** |
| Interval | 拍 | 同上 |
| 用例数 / 通过数 | / | `*_csim.log` 末尾 |
| 协同仿真结果 | Pass / Fail | `*_cosim.rpt` |
| 事务级延迟 min/avg/max | 拍 | `*_transaction.rpt` |

## 三、分模块数据表（瓶颈定位用）

| 模块 | BRAM | DSP | FF | LUT | Interval | 备注 |
|---|---|---|---|---|---|---|
| 顶层（含全部） |  |  |  |  |  |  |
| 处理级 1 |  |  |  |  |  |  |
| 处理级 2 |  |  |  |  |  |  |
| 处理级 3 |  |  |  |  |  |  |

> 填表后横向比对：**Interval 最大的一级即为瓶颈**。但若其与单帧像素数仅差百分之几，则属次级瓶颈，不应作为主要优化对象（本工程 sobel 级差 1.2%，其优化收益远小于算法层调整）。

## 四、整机数据表（系统实现后，通常由集成方提供）

| 项 | 值 | 出处 |
|---|---|---|
| LUT / 占比 |  | `utilization_placed.rpt` |
| FF / 占比 |  | 同上 |
| BRAM / 占比 |  | 同上 |
| DSP / 占比 |  | 同上 |
| WNS | ns | `timing_summary_routed.rpt` |
| WHS | ns | 同上 |
| TNS | ns | 同上 |
| 违例端点 / 总端点 | / | 同上 |
| 约束周期（**WNS 对应的那个**） | ns | 同上，Clock Summary |

## 五、三张表之间的三条界线

| 界线 | 错误写法 | 正确写法 |
|---|---|---|
| 单 IP 与整机 | "HLS 用 7392 个 LUT，系统 7514，因此集成了 122 个" | "单 IP 估计 7392 LUT；整机实现 7514 LUT（含 dvi2rgb、rgb2dvi、interconnect 等 11 个模块）" |
| 估计与实测 | "时序满足 100 MHz" | "HLS 估计关键路径 7.300 ns（综合目标 10 ns）；实现后像素时钟组周期 13.468 ns（74.25 MHz）、组内 WNS +1.562 ns；整机汇总 WNS +0.661 ns 来自 `clk_fpga_1`，均无违例" |
| 计算、仿真与估算 | "80.6 fps，加速 33.5×"混合表述 | 理论 12.412 ms / 80.6 fps（计算值）；协同仿真平均 12.505 ms / 80.0 fps、最大 12.573 ms / 79.5 fps（`dehaze_cosim.rpt`）；综合估算 12.540 / 12.591 ms（`csynth.rpt`）。三类分列，各附来源 |

## 六、同一份 rpt 中出现两个数值时的处理

本工程实际遇到：同一份 `dehaze_csynth.rpt` 中，

| 位置 | LUT |
|---|---|
| Performance & Resource Estimates 表的模块行 | 7392（13%） |
| Utilization Estimates 表的 Total 行 | 7388 |

差值 4 不属错误：Total 行对共享逻辑的计数方式不同。处理方式：

1. **选定一个值，全文档统一**，并在脚注注明"取自 Total 行"或"取自模块行"
2. 不得使两个数值同时出现在正文不同段落
3. `scripts/extract_qor.py` 默认取 Total 行；报告无 Total 行时回退至模块行，并在 `note` 列注明

## 七、填表后的摘要表述

模板：

> 该 IP 在 <器件> 上以 <约束周期> 约束综合，估计关键路径 <估计周期>，
> 占用 <BRAM> 个 BRAM_18K、<DSP> 个 DSP、<FF> 个 FF、<LUT> 个 LUT；
> 顶层 Latency <min>~<max> 拍，Latency Type 为 <dataflow/no>；
> <N> 个 C 仿真用例全部通过，协同仿真 <M> 个事务全部 Pass，事务级延迟 <a>~<b> 拍。
