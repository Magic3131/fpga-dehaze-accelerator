
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [1:0] axis_block_sigs;
wire [10:0] inst_idle_sigs;
wire [7:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~Loop_VITIS_LOOP_372_1_proc5_U0.in_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~Loop_VITIS_LOOP_379_2_proc6_U0.out_stream_TDATA_blk_n;

assign inst_idle_sigs[0] = entry_proc9_U0.ap_idle;
assign inst_block_sigs[0] = (entry_proc9_U0.ap_done & ~entry_proc9_U0.ap_continue) | ~entry_proc9_U0.ctrl_reg_c14_blk_n | ~entry_proc9_U0.threshold_reg_c15_blk_n;
assign inst_idle_sigs[1] = Loop_VITIS_LOOP_372_1_proc5_U0.ap_idle;
assign inst_block_sigs[1] = (Loop_VITIS_LOOP_372_1_proc5_U0.ap_done & ~Loop_VITIS_LOOP_372_1_proc5_U0.ap_continue) | ~Loop_VITIS_LOOP_372_1_proc5_U0.rgb_input_blk_n;
assign inst_idle_sigs[2] = dehaze_core_U0.ap_idle;
assign inst_block_sigs[2] = (dehaze_core_U0.ap_done & ~dehaze_core_U0.ap_continue) | ~dehaze_core_U0.dark_window_U0.grp_dark_window_Pipeline_WINDOW_BYPASS_fu_72.rgb_input174_blk_n | ~dehaze_core_U0.dark_window_U0.grp_dark_window_Pipeline_WINDOW_ROWS_WINDOW_COLS_fu_80.rgb_input174_blk_n | ~dehaze_core_U0.restore_stream_U0.grp_restore_stream_Pipeline_RESTORE_ROWS_RESTORE_COLS_fu_298.dehazed175_blk_n | ~dehaze_core_U0.restore_stream_U0.grp_restore_stream_Pipeline_RESTORE_BYPASS_fu_290.dehazed175_blk_n | ~dehaze_core_U0.entry_proc_U0.ctrl_blk_n | ~dehaze_core_U0.entry_proc_U0.params_blk_n | ~dehaze_core_U0.entry_proc_U0.ctrl_reg_c_blk_n | ~dehaze_core_U0.entry_proc_U0.threshold_reg_c_blk_n;
assign inst_idle_sigs[3] = sobel_core_U0.ap_idle;
assign inst_block_sigs[3] = (sobel_core_U0.ap_done & ~sobel_core_U0.ap_continue) | ~sobel_core_U0.grp_sobel_core_Pipeline_VITIS_LOOP_276_4_fu_229.dehazed175_blk_n | ~sobel_core_U0.grp_sobel_core_Pipeline_VITIS_LOOP_253_1_fu_211.dehazed175_blk_n | ~sobel_core_U0.processed176_blk_n | ~sobel_core_U0.grp_sobel_core_Pipeline_VITIS_LOOP_276_4_fu_229.processed176_blk_n | ~sobel_core_U0.grp_sobel_core_Pipeline_VITIS_LOOP_318_5_fu_256.processed176_blk_n | ~sobel_core_U0.grp_sobel_core_Pipeline_VITIS_LOOP_253_1_fu_211.processed176_blk_n | ~sobel_core_U0.ctrl_reg_blk_n | ~sobel_core_U0.threshold_reg_blk_n;
assign inst_idle_sigs[4] = Loop_VITIS_LOOP_379_2_proc6_U0.ap_idle;
assign inst_block_sigs[4] = (Loop_VITIS_LOOP_379_2_proc6_U0.ap_done & ~Loop_VITIS_LOOP_379_2_proc6_U0.ap_continue) | ~Loop_VITIS_LOOP_379_2_proc6_U0.processed_blk_n;
assign inst_idle_sigs[5] = dehaze_core_U0.entry_proc_U0.ap_idle;
assign inst_block_sigs[5] = (dehaze_core_U0.entry_proc_U0.ap_done & ~dehaze_core_U0.entry_proc_U0.ap_continue);
assign inst_idle_sigs[6] = dehaze_core_U0.dark_window_U0.ap_idle;
assign inst_block_sigs[6] = (dehaze_core_U0.dark_window_U0.ap_done & ~dehaze_core_U0.dark_window_U0.ap_continue);
assign inst_idle_sigs[7] = dehaze_core_U0.restore_stream_U0.ap_idle;
assign inst_block_sigs[7] = (dehaze_core_U0.restore_stream_U0.ap_done & ~dehaze_core_U0.restore_stream_U0.ap_continue);

assign inst_idle_sigs[8] = 1'b0;
assign inst_idle_sigs[9] = Loop_VITIS_LOOP_372_1_proc5_U0.ap_idle;
assign inst_idle_sigs[10] = Loop_VITIS_LOOP_379_2_proc6_U0.ap_idle;

dehaze_hls_deadlock_idx0_monitor dehaze_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
