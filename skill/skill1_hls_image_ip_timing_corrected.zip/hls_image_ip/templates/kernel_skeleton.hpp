// ============================================================================
//  02 案例模板 / kernel_skeleton.hpp
//
//  流式图像 IP 的最小骨架：双行缓存 + 3x3 滑窗 + 32bit 打包 + 尾部冲空
//
//  设计要点（各条对应的故障案例见 pitfalls）：
//    1. 行缓存用两个独立一维数组 + row&1 选通，不用 ARRAY_PARTITION  (K02)
//    2. 元素是 32bit 打包字：[31:24]=派生值(如暗通道), [23:0]=RGB888  (K03)
//       —— 下游一拍内同时获得两者，无需额外延迟线
//    3. 窗口三行只从 prev 读 1 个新值，其余由寄存器滑动补足，压成 1 读 1 写 (K02)
//    4. 主循环之外运行 WIDTH+1 拍 tail 循环冲空流水线，边界复制由此实现
//    5. 不出现变量除法，改用倒数表                                  (K04)
//
//  适配自有设计的三处修改：
//    - 修改 WIDTH/HEIGHT
//    - 将 derive() 替换为自有派生值计算（无需该值则固定返回 0）
//    - 将 process_pixel() 替换为自有 3x3 运算
//
//  验证状态
//     结构（双数组选通、32bit 打包、寄存器滑动、tail 冲空）取自一份已验证的设计：
//     该设计在 1280x720 下 II=1、行缓存占 2 块 BRAM、打包字落 LUTRAM。
//     本文件为**简化抽取**，算法部分以占位实现替代。
//     已验证：g++ -std=c++14 -fsyntax-only -I<Vitis HLS>/include 语法检查通过
//             （与 tb_template.cpp 联合编译，0 warning 0 error）。
//     未验证：未在 1280x720 下运行 csim，未产出 csynth 资源数据。
//     使用定位：结构参考与可编译起点，非已完成综合验证的工程。
// ============================================================================
#ifndef KERNEL_SKELETON_HPP
#define KERNEL_SKELETON_HPP

#include <ap_int.h>
#include <hls_stream.h>
#include <ap_axi_sdata.h>

// ---- 图像尺寸：以 #ifndef 保护，便于外部 -D 覆盖（快速回归可缩至 64x48）----
#ifndef IMG_WIDTH
#define IMG_WIDTH  1280
#endif
#ifndef IMG_HEIGHT
#define IMG_HEIGHT 720
#endif

static const int WIDTH  = IMG_WIDTH;
static const int HEIGHT = IMG_HEIGHT;

// ---- 打包字：高 8 位派生值 + 低 24 位 RGB ----
typedef ap_uint<32> window_t;
#define PACK(derived, rgb) ((((window_t)(derived)) << 24) | ((window_t)(rgb) & 0xFFFFFFu))
#define DERIVED(w)         ((ap_uint<8>)((w) >> 24))
#define RGB(w)             ((ap_uint<24>)((w) & 0xFFFFFFu))

// ---- 流接口类型：24bit 数据 + TUSER(帧首) + TLAST(行尾) ----
typedef hls::axis<ap_uint<24>, 1, 1, 1> axis_pix_t;

// ============================================================================
//  派生值：每像素与 RGB 同源同拍算出来，随像素一起进 FIFO
//  典型用途：暗通道 (min(R,G,B))、灰度、饱和度……
// ============================================================================
inline ap_uint<8> derive(ap_uint<24> rgb) {
    ap_uint<8> r = rgb(23, 16);
    ap_uint<8> g = rgb(15, 8);
    ap_uint<8> b = rgb(7, 0);
    ap_uint<8> m = r;
    if (g < m) m = g;
    if (b < m) m = b;
    return m;                      // 暗通道
}

// ============================================================================
//  3x3 运算：输入为九宫格（每个元素含派生值与 RGB），输出一个像素
//  当前实现为恒等输出，用于先行打通接口
// ============================================================================
inline ap_uint<24> process_pixel(window_t p00, window_t p01, window_t p02,
                                 window_t p10, window_t p11, window_t p12,
                                 window_t p20, window_t p21, window_t p22) {
#pragma HLS INLINE
    // 示例：中心像素原样输出。替换为自有算法时保持函数签名不变。
    // 约束：九宫格在同一拍内只读，不在此处写回数组。
    (void)p00; (void)p01; (void)p02;
    (void)p10; (void)p12;
    (void)p20; (void)p21; (void)p22;
    return RGB(p11);
}

// ============================================================================
//  顶层内核
// ============================================================================
inline void kernel_top(hls::stream<axis_pix_t> &in_stream,
                       hls::stream<axis_pix_t> &out_stream) {
#pragma HLS INTERFACE axis      port=in_stream
#pragma HLS INTERFACE axis      port=out_stream
#pragma HLS INTERFACE s_axilite port=return bundle=CTRL
    // 说明：仅使用一个 s_axilite bundle=CTRL，使 return 的 ap_ctrl 落于 0x00
    //       此时无 ap_start 端口，每帧通过写 0x00 的 bit0 触发（见 K07）

    static window_t line_a[WIDTH];
    static window_t line_b[WIDTH];
#pragma HLS BIND_STORAGE variable=line_a type=ram_s2p impl=bram
#pragma HLS BIND_STORAGE variable=line_b type=ram_s2p impl=bram
    // 显式绑定 BRAM 非必需（见 K01：索引静态化后有无均可），
    // 但可避免工具在小尺寸下推断为 LUTRAM 导致资源波动。

    ap_uint<11> col = 0;
    ap_uint<11> row = 0;

    // 寄存器滑动：三行窗口仅从 prev 读 1 个新值，其余两个由寄存器传递
    window_t up_l = 0, up_c = 0, up_r = 0;   // 上一行 左/中/右
    window_t md_l = 0, md_c = 0, md_r = 0;   // 当前行 左/中/右

    // 主循环 + tail：以 WIDTH+1 拍冲空流水线，同时完成右边界复制
    const int TOTAL = WIDTH * HEIGHT + WIDTH + 1;
KERNEL_LOOP:
    for (int n = 0; n < TOTAL; ++n) {
#pragma HLS PIPELINE II=1
#pragma HLS LOOP_TRIPCOUNT min=921600 max=922881

        window_t px;
        bool     valid = (n < WIDTH * HEIGHT);

        if (valid) {
            axis_pix_t pkt = in_stream.read();
            px = PACK(derive(pkt.data), pkt.data);
            // 帧首/行尾处理：以 TUSER 复位内部计数，不依赖计数自然溢出 (K07)
            if (pkt.user) { row = 0; col = 0; }
        } else {
            px = 0;                          // tail 阶段送 0，仅用于冲空流水线
        }

        // ---- 行奇偶选通：prev 指向上一行，cur 指向当前行 ----
        window_t *prev = (row & 1) ? line_b : line_a;
        window_t *cur  = (row & 1) ? line_a : line_b;

        // ---- 每拍仅读 1 个新值，其余由寄存器提供 ----
        window_t fresh = (col < WIDTH) ? prev[col] : up_r;   // 越界时复制右边界

        if (valid) {
            cur[col] = px;                   // 每拍 1 写
        }

        // 三行窗口：由 fresh 推动三个寄存器，构成 (row-1, col-1..col+1)
        up_l = up_c;  up_c = up_r;  up_r = fresh;
        md_l = md_c;  md_c = md_r;

        // ---- 输出对齐：窗口中心 (row,col) 的结果属于 (row-1, col-1) ----
        if (valid && row > 0 && col > 0) {
            axis_pix_t o;
            o.data = process_pixel(up_l, up_c, up_r,
                                   md_l, md_c, 0,
                                   0,    0,    0);
            o.last = (col == WIDTH - 1);
            o.user = (row == 1 && col == 1);
            o.keep = -1;
            out_stream.write(o);
        }

        // ---- 计数推进 ----
        if (valid) {
            if (col == WIDTH - 1) { col = 0; row++; md_r = px; }
            else                  { col++;         md_r = px; }
        }
    }
}

#endif // KERNEL_SKELETON_HPP
