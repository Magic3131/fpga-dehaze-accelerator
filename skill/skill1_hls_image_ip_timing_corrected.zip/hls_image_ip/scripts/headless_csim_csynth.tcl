# ============================================================
#  scripts / headless_csim_csynth.tcl
#  用途：不启动 GUI，以命令行运行 csim + csynth，不干扰已打开的工程
#
#  用法（PowerShell / cmd）：
#    set HLS=<工具安装目录>\bin\vitis_hls.bat
#    "%HLS%" -f headless_csim_csynth.tcl <源码目录> <顶层函数名> [full|nocsim]
#
#  示例（以下路径均为示例值，使用时替换为实际路径）：
#    set HLS=D:\Vitis_HLS\2022.2\bin\vitis_hls.bat
#    "%HLS%" -f headless_csim_csynth.tcl D:/proj/src dehaze
#
#  脚本内不含固定工程路径：源码目录与顶层名均通过参数或环境变量传入。
#
#  亦可以环境变量代替参数：HLS_SRC / HLS_TOP / HLS_MODE
#
#  脚本已处理以下三类环境问题（开发过程中实际遇到）：
#    1. vitis_hls 会将 "-f" 与脚本名一并放入 argv，直接取 argv[0] 得到的是 "-f"
#    2. 工程目录含中文时，open_solution 在 set_msg_logfile 处报错退出
#    3. 源码路径含中文时，csim 的 make 无法识别路径，报 "No such file or directory"
#  处置：检测非 ASCII 路径 → 工程目录退至 %TEMP%；源码先复制到 ASCII 暂存目录。
#
#  输出内容全部为 ASCII：Windows 控制台使用 GBK 编码，中文 puts 会出现乱码。
# ============================================================

set here [file normalize [file dirname [info script]]]

# ---- 1. 取参数（滤掉 vitis_hls 塞进来的杂项）----
set pos_list {}
foreach a $argv {
    if {$a eq "-f" || $a eq "-tclargs"} { continue }
    if {[string match "*.tcl" $a]} { continue }
    lappend pos_list $a
}

set src_dir  [expr {[llength $pos_list] > 0 ? [lindex $pos_list 0] : [expr {[info exists ::env(HLS_SRC)]  ? $::env(HLS_SRC)  : "."}]}]
set top_name [expr {[llength $pos_list] > 1 ? [lindex $pos_list 1] : [expr {[info exists ::env(HLS_TOP)]  ? $::env(HLS_TOP)  : "dehaze"}]}]
set mode     [expr {[llength $pos_list] > 2 ? [lindex $pos_list 2] : [expr {[info exists ::env(HLS_MODE)] ? $::env(HLS_MODE) : "full"}]}]
if {[lsearch {full nocsim} $mode] < 0} { set mode "full" }

set src_dir [file normalize $src_dir]

# ---- 2. 工程目录：非 ASCII 就退到 %TEMP% ----
proc is_ascii {s} { return [regexp {^[\x00-\x7F]*$} $s] }

set prj_dir [file join $here _verify]
if {![is_ascii $prj_dir]} {
    set prj_dir [file join $::env(TEMP) hls_verify]
}
file mkdir $prj_dir
set prj_dir [file normalize $prj_dir]

puts "============================================================"
puts "SRC  : $src_dir"
puts "TOP  : $top_name"
puts "MODE : $mode"
puts "WORK : $prj_dir"
puts "============================================================"

# ---- 3. 源码暂存到 ASCII 目录（避开 make 的中文路径问题）----
set stage [file join $prj_dir src]
if {[file exists $stage]} { file delete -force $stage }
file mkdir $stage

set copied 0
foreach pat {*.cpp *.hpp *.h} {
    foreach f [glob -nocomplain [file join $src_dir $pat]] {
        file copy -force $f $stage
        incr copied
    }
}
puts "staged $copied file(s)"

foreach f [list "${top_name}.cpp" "${top_name}_test.cpp"] {
    if {![file exists [file join $stage $f]]} {
        puts "ERROR: not found: [file join $src_dir $f]"
        exit 1
    }
}

# ---- 4. 建工程（顺序不能换）----
cd $prj_dir
if {[file exists verify_prj]} { file delete -force verify_prj }

open_project verify_prj
set_top $top_name

foreach pat {*.hpp *.h} {
    foreach f [lsort [glob -nocomplain [file join $stage $pat]]] {
        add_files $f
    }
}
add_files [file join $stage ${top_name}.cpp]
add_files -tb [file join $stage ${top_name}_test.cpp] \
    -cflags "-Wno-unknown-pragmas" -csimflags "-Wno-unknown-pragmas"

# flow_target 必须在 open_solution 时给；set_part / create_clock 必须在其后、csynth 之前
open_solution "sol1" -flow_target vivado
set_part {xc7z020-clg400-1}
create_clock -period 10 -name default

# ---- 5. C 仿真 ----
if {$mode ne "nocsim"} {
    puts "\n>>> csim_design"
    set t0 [clock seconds]
    if {[catch {csim_design -quiet} err]} {
        puts "ERROR: csim failed: $err"
        exit 2
    }
    puts "csim done in [expr {[clock seconds] - $t0}] s"
}

# ---- 6. C 综合 ----
puts "\n>>> csynth_design"
set t0 [clock seconds]
if {[catch {csynth_design} err]} {
    puts "ERROR: csynth failed: $err"
    exit 3
}
puts "csynth done in [expr {[clock seconds] - $t0}] s"

# ---- 7. 摘要（省得去翻报告）----
set rpt [file join verify_prj sol1 syn report ${top_name}_csynth.rpt]
if {[file exists $rpt]} {
    set fh [open $rpt r]
    set body [read $fh]
    close $fh
    puts "\n============================================================"
    foreach pat {
        {Target device:\s*(\S+)}
        {Estimated:\s*([\d.]+ ns)}
    } {
        if {[regexp $pat $body -> val]} { puts $val }
    }
    # 报告里有多张表都带 "Total" 行，只取资源那张（5 个数字列）
    foreach ln [split $body "\n"] {
        if {[string match "*Total*" $ln] && [regexp {\|\s*\d+\|\s*\d+\|\s*\d+\|\s*\d+\|\s*\d+\|} $ln]} {
            puts "UTIL: [string trim $ln]"
            break
        }
    }
    puts "RPT  : $rpt"
    puts "============================================================"
}

exit 0

# ============================================================
#  缩分辨率回归方法（cosim 由约 40 分钟降至约 2 分钟）
# ------------------------------------------------------------
#  前提：头文件以 #ifndef 保护，例如
#      #ifndef IMG_WIDTH
#      #define IMG_WIDTH  1280
#      #endif
#  此时可加入 -cflags "-DIMG_WIDTH=64 -DIMG_HEIGHT=48"，无需修改头文件本体。
#
#  若头文件为裸 #define（无法从命令行覆盖），只能临时修改后还原：
#      copy config.hpp config.hpp.bak
#      powershell -c "(gc config.hpp) -replace '1280','64' -replace '720','48' | sc config.hpp"
#      运行结束： move /y config.hpp.bak config.hpp
#
#  恢复原分辨率后须重新执行完整流程，否则报告对应的是缩小后的配置。
# ============================================================
