# skill1

本目录收录一个可复用的技能包：**HLS 图像 IP 技能包**（`hls_image_ip/`）。

| 包 | 内容 | 入口 |
|---|---|---|
| `hls_image_ip/` | 图像算法到 FPGA IP 的工程方法，覆盖综合、仿真、验证与交付；含提示词工作流、案例模板、校验脚本、常见错误案例与通用方法 | [`hls_image_ip/README.md`](hls_image_ip/README.md) |

---

## 目录结构

```
skill1/
├── README.md               本文件（索引）
└── hls_image_ip/
    ├── README.md           技能包正文入口
    ├── prompts/            4 条提示词工作流（算法到划分、报告到瓶颈、报错到根因、口径审计）
    ├── templates/          骨架、测试台、寄存器表、综合数据表
    ├── scripts/            环境自检、无头 csim+csynth、QoR 提取、循环编号核验
    ├── pitfalls/           12 个常见错误案例（K01~K12）
    ├── pynq_guide/         5 章通用方法（工具链、微架构、接口契约、时序口径、上板链路）
    └── integration/        IP 对系统的六条要求与地址反查方法
```

## 使用顺序

1. 阅读 `hls_image_ip/README.md` 的"包内结构"与"数据口径约定"两节，确认内容覆盖当前问题。
2. 新建设计：以 `templates/kernel_skeleton.hpp` 为结构起点，按 `prompts/` 的 P1 完成硬件划分。
3. 故障定位：按 `pitfalls/README.md` 的症状索引检索，不按标题推断。
4. 撰写报告：先用 `prompts/p4_data_caliber_audit.md` 核对全部数字，再用 `pynq_guide/04_timing_and_data_caliber.md` 核对时序表述。

## 编写约定

- 目录名与文件名使用英文，正文为中文；新增内容沿用此约定。
- 包内脚本的运行记录来自单一环境（Vitis HLS 2022.2 / Windows 10）。更换环境后，耗时与资源数据不再成立，需按本机结果重新记录。运行条件与路径约定见 `hls_image_ip/scripts/README.md` 第一、二节。
