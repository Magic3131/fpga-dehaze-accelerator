#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
scripts / loop_id_consistency.py

问题
    Vitis HLS 以 `VITIS_LOOP_<源码行号>_<序号>` 命名循环。
    源码增删一行，全部编号即发生平移，而综合报告仍为旧版本。
    此时"报告中 7 个循环全部 II=1"可能描述的是三小时前的代码。

    这类错误的代价最高：数值均为真实，但对应的是另一个版本的设计。

脚本功能
    将源码中的循环行号与报告中出现的 VITIS_LOOP 编号逐一对照，输出四类结果：
      [一致]   报告中的编号在源码对应行确实为循环
      [失配]   编号指向的行不是循环（代码已修改，报告过期）
      [越界]   编号超过源码总行数（报告来自更长的旧版本）
      [未覆盖] 源码中存在循环但报告中未出现（可能被展平或内联，也可能未被综合）

用法
    python loop_id_consistency.py 源码.cpp 报告目录_or_rpt...
    python loop_id_consistency.py <源码>.cpp <报告目录>

退出码
    0 = 全部一致；1 = 存在失配或越界（报告不可引用）

适用边界
    仅对"循环实体仍在源码中"的情形有效。若循环被完全展平（unroll 后不再存在），
    报告中会出现源码已无对应行的编号，此时报"失配"属正常现象，
    可使用 --allow-flattened 将其降级为提示。
"""

import argparse
import os
import re
import sys

# 报告里的循环编号：VITIS_LOOP_372_1 / Loop_VITIS_LOOP_372_1_proc5
RE_LOOP_ID = re.compile(r"LOOP_(\d+)_(\d+)")

# 源码里的循环起始行（粗略但足够：for/while 后跟左括号）
RE_LOOP_LINE = re.compile(r"\b(for|while)\s*\(")


def strip_comments(line):
    """去掉行内注释与字符串，避免把注释里的 'for(' 当循环。"""
    line = re.sub(r"//.*$", "", line)
    line = re.sub(r'"(?:[^"\\]|\\.)*"', '""', line)
    line = re.sub(r"/\*.*?\*/", "", line)
    return line


def scan_source(path):
    loops = {}          # 行号 -> 该行内容（截断）
    total = 0
    in_block = False
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for no, raw in enumerate(f, 1):
            total = no
            line = raw
            if in_block:
                if "*/" in line:
                    line = line.split("*/", 1)[1]
                    in_block = False
                else:
                    continue
            while "/*" in line and "*/" not in line.split("/*", 1)[1]:
                line = line.split("/*", 1)[0]
                in_block = True
                break
            line = strip_comments(line)
            if RE_LOOP_LINE.search(line):
                loops[no] = raw.strip()[:72]
    return loops, total


def scan_reports(paths):
    """返回 {(行号, 序号): 首次出现的文件名} 与来源文件列表。"""
    ids = {}
    files = []
    labels = set()
    for p in paths:
        if os.path.isdir(p):
            cand = [os.path.join(p, n) for n in sorted(os.listdir(p))
                    if n.endswith((".rpt", ".log"))]
        elif os.path.isfile(p):
            cand = [p]
        else:
            print(f"[跳过] 不存在: {p}", file=sys.stderr)
            continue
        for f in cand:
            files.append(f)
            labels.update(re.findall(r"Pipeline_(\w+)", os.path.basename(f)))
            with open(f, "r", encoding="utf-8", errors="replace") as fh:
                for ln in fh:
                    labels.update(re.findall(r"Pipeline_(\w+)", ln))
                    for m in RE_LOOP_ID.finditer(ln):
                        key = (int(m.group(1)), int(m.group(2)))
                        ids.setdefault(key, os.path.basename(f))
    return ids, files, labels


def main():
    ap = argparse.ArgumentParser(description="源码行号 ↔ VITIS_LOOP 编号一致性核验")
    ap.add_argument("source", help="源码文件（.cpp）")
    ap.add_argument("reports", nargs="+", help="报告目录或 .rpt/.log 文件")
    ap.add_argument("--allow-flattened", action="store_true",
                    help="将'源码无对应行'降级为提示（适用于循环被展平的情形）")
    args = ap.parse_args()

    if not os.path.isfile(args.source):
        print(f"源码不存在: {args.source}", file=sys.stderr)
        return 1

    loops, total = scan_source(args.source)
    ids, files, labels = scan_reports(args.reports)

    print("=" * 78)
    print(f"源码 : {os.path.basename(args.source)}  ({total} 行, {len(loops)} 个循环)")
    print(f"报告 : {len(files)} 个文件, {len(ids)} 个循环编号")
    print("=" * 78)

    ok, bad, over, miss = [], [], [], []

    for (line, seq), src in sorted(ids.items()):
        if line > total:
            over.append((line, seq, src))
        elif line in loops:
            ok.append((line, seq, loops[line]))
        else:
            bad.append((line, seq, src))

    named, miss = [], []
    for line in sorted(loops):
        if any(l == line for (l, _) in ids):
            continue
        m = re.search(r"([A-Z][A-Z_0-9]{2,})\s*:\s*(for|while)", loops[line])
        if m and any(lab == m.group(1) or lab.startswith(m.group(1)) for lab in labels):
            named.append((line, m.group(1), loops[line]))
        else:
            miss.append((line, loops[line]))

    if ok:
        print(f"\n[一致] {len(ok)} 处 —— 报告编号在源码对应行确为循环")
        for line, seq, txt in ok:
            print(f"   L{line:<6} LOOP_{line}_{seq}   {txt}")

    if bad:
        print(f"\n[失配] {len(bad)} 处 —— 报告编号指向的行不是循环，报告可能已过期")
        for line, seq, src in bad:
            near = min(loops, key=lambda x: abs(x - line)) if loops else None
            hint = f"（最近的循环在 L{near}）" if near else ""
            print(f"   L{line:<6} LOOP_{line}_{seq}  出自 {src} {hint}")

    if over:
        print(f"\n[越界] {len(over)} 处 —— 编号超过源码总行数 {total}，报告来自更长的旧版本")
        for line, seq, src in over:
            print(f"   L{line:<6} LOOP_{line}_{seq}  出自 {src}")

    if named:
        print(f"\n[具名] {len(named)} 处 —— 源码用标签命名，报告里以 Pipeline_<标签> 出现（正常）")
        for line, lab, txt in named:
            print(f"   L{line:<6} {lab}")

    if miss:
        print(f"\n[未覆盖] {len(miss)} 处 —— 源码有循环但报告里没有")
        for line, txt in miss:
            print(f"   L{line:<6} {txt}")
        print("   说明：被完全展平的循环不会出现在报告中，属正常；否则应确认该循环是否被综合")

    print("\n" + "=" * 78)
    fatal = len(bad) + len(over)
    if fatal:
        from_log = [x for x in bad + over if x[2].endswith(".log")]
        if len(from_log) == fatal:
            print(f"结论：{fatal} 处失配全部来自 .log。")
            print("      报告本身无误，日志中混有旧版本运行的循环编号（见 K10）。")
            print("      引用数值仅使用 .rpt；日志用于查历史，不可作为证据。")
            return 0
        else:
            print(f"结论：{fatal} 处不可信，报告不可直接引用，须重跑 csynth 后再引用数值。")
        return 1
    if miss and not args.allow_flattened:
        print(f"结论：编号全部一致，但有 {len(miss)} 个源码循环未出现在报告中，须人工确认。")
        return 0
    print("结论：源码与报告编号完全对应，报告中数值可直接引用。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
