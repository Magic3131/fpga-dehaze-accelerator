# HLS 图像 IP 技能包

本包整理图像算法到 FPGA IP 的完整链路：**可综合、可仿真、可验证、可交付**；并将该链路上的故障案例、数据口径与验证方法整理为可复用的形式。

适用对象：从事流式图像 IP 设计、需在有限开发周期内完成从算法到上板的开发者。
前置要求：具备 C/C++ 编程能力，了解流水线与 AXI 总线的基本概念，尚无完整 IP 设计经验。

编写约定：目录名与文件名使用英文，正文为中文。

---

## 一、覆盖范围

流式图像 IP 的工程难点通常不在算法本身，而集中在以下三类：

| 类别 | 典型表现 | 对应内容 |
|---|---|---|
| **综合失败或耗时异常** | 停在 `HLS 200-777` 数小时；`Unable to schedule`；II 无法达到 1 | `pynq_guide/01`，`pitfalls/` K01 K02 K06 |
| **仿真结果与预期不符** | 输出对比度下降、边缘偏移 1 像素、画面斜切 | `templates/` 测试台，`pitfalls/` K03 K05 K07 |
| **数据口径不一致** | 资源、时序、帧率相互矛盾；数值无法追溯出处 | `prompts/` P2 P4，`scripts/` QoR 与循环核验，`pynq_guide/04` |

---

## 二、包内结构

```
hls_image_ip/
├── README.md               本文件
├── prompts/                4 条，将大模型辅助过程固化为可复现的流程
├── templates/              4 个，骨架 / 测试台 / 寄存器表 / 综合数据表
├── scripts/                4 个脚本 + 1 次运行记录
├── pitfalls/               12 个案例，按症状检索
├── pynq_guide/             5 章，与题目、板卡无关的通用方法
└── integration/            IP 对系统的要求 + 地址反查方法
```

### 各目录内容

| 目录 | 内容 | 文件数 | 适用阶段 |
|---|---|---|---|
| `prompts/` | P1 算法到硬件划分、P2 综合报告读瓶颈、P3 报错到根因假设、P4 数据口径审计 | 5 | 设计前、故障定位、成文前 |
| `templates/` | `templates/kernel_skeleton.hpp`（双行缓存 + 3×3 窗口）、`templates/tb_template.cpp`（全帧逐像素比对）、`templates/regmap_template.md`、`templates/csynth_data_template.md` | 5 | 新建工程时作为结构起点 |
| `scripts/` | 环境自检、无头 csim+csynth、QoR 提取、循环编号核验 | 5 + 2 份运行记录 | 代码修改后、报告提交前 |
| `pitfalls/` | K01~K12，每条含现象、触发条件、三步定位、处置、验证判据、适用边界 | 13 | 故障定位 |
| `pynq_guide/` | 工具链、微架构通则、接口与寄存器契约、时序与数据口径、上板链路 | 6 | 理解设计依据 |
| `integration/` | IP 的六条系统要求、`.hwh` 反查地址、系统构成与参数口径 | 1 | IP 接入系统 |

共 **38 个文件**：36 份文档与脚本，加 2 份运行记录（`scripts/results/`）。

---

## 三、内容分类

| 类别 | 内容 | 位置 |
|---|---|---|
| **提示词工作流** | 4 条，每条含适用场景、提问模板、输出检查表、实测效果、适用边界 | `prompts/` |
| **案例模板** | 4 个，两个代码模板已完成语法检查，两个表格模板可直接填写 | `templates/` |
| **校验脚本** | 4 个，运行条件见 `scripts/README.md`，附一次完整运行记录 | `scripts/` |
| **常见错误案例** | 12 条，每条六要素齐全，来源为实际返工过程 | `pitfalls/` |
| **通用方法** | 5 章，另 1 章接口说明，均剥离具体题目与分辨率 | `pynq_guide/`、`integration/` |

---

## 四、验证状态与运行条件

包内凡含具体数值的内容，下表列明测量对象与测量条件。

| 项 | 运行 / 检查方式 | 结果 | 条件 |
|---|---|---|---|
| `scripts/hls_env_check.bat` | `cmd /c` 实跑 | 识别出 mingw g++ 静默失败与 DLL 缺失两类问题 | Windows 10 + Vitis HLS 2022.2 |
| `scripts/headless_csim_csynth.tcl` | 无头运行 csim + csynth | csim 16 个用例通过（217 s）；csynth 53 s；13 BRAM / 10 DSP / 5109 FF / 7388 LUT | 同上，源码 4 个文件，顶层 `dehaze` |
| `scripts/extract_qor.py` | 对 19 份 `csynth.rpt` 运行 | 输出 19 行 CSV，并显示 7392 / 7388 两种计数视图 | 报告由 Vitis HLS 2022.2 生成 |
| `scripts/loop_id_consistency.py` | 对源码与报告目录运行 | 14 处一致、9 处失配（全部出自 `.log`） | 同上 |
| `templates/kernel_skeleton.hpp` + `templates/tb_template.cpp` | `g++ -std=c++14 -fsyntax-only` | 0 error、0 warning | 仅语法检查，未运行 csim / csynth |

**未覆盖范围**：模板本身未做综合；脚本未在 Vitis HLS 2023.x、Linux、macOS 上运行；`pitfalls/` 中 K08 为设计推断，条目内已标注未经实验验证。

---

## 五、数据口径约定

包内涉及性能的数值分四类，引用时不可混用：

| 量 | 值 | 性质 | 来源 |
|---|---|---|---|
| 每帧理论时间 | 921,600 px ÷ 74.25 MHz = **12.412 ms**（80.6 fps） | **计算值**（1 像素/时钟） | 分辨率与像素时钟 |
| 协同仿真延迟 | min/avg/max = 921,644 / 928,494 / **933,587 拍**<br>→ 12.411 / 12.505 / **12.573 ms** | **仿真值** | `dehaze_cosim.rpt`，16 个事务 |
| 综合估算延迟 | 931,125 / 934,980 拍 → 12.540 / 12.591 ms | **工具估算** | `csynth.rpt`，`Latency Type = dataflow` |
| 上板计数器 | 首像素延迟 **1,674 拍 = 22.5 µs ≈ 1.01 行**（1,650 拍/行）；27 帧读数一致 | **板上读数** | 帧首到帧首计数器 |

由此产生三条引用约定：

1. **12.412 ms 为计算值，非测量值。** 其成立前提是"每时钟 1 像素"，在已设置约束下，像素时钟组 `PixelClk_int` 的 WNS 为 +1.562 ns；整机汇总 WNS +0.661 ns 来自另一时钟组 `clk_fpga_1`。
2. **79.5 fps 对应协同仿真最大延迟 933,587 拍**（12.573 ms）；平均延迟 928,494 拍对应 12.505 ms / 80.0 fps。两者各有对应口径，不可互换，也不与 80.6 fps 并列使用。
3. **27 帧读数一致仅说明该测量窗口内每帧周期数未增长**，不构成"长时间运行无劣化"的结论。

加速比同理：33.5×（对 12.412 ms）、33.2×（对 12.505 ms）、33.1×（对 12.573 ms）。正文取一个，脚注列全并注明依据。

---

## 六、使用路径

**路径 A：从零实现一个图像 IP**

以 `templates/kernel_skeleton.hpp` 为结构起点；先将 `process_pixel()` 改为恒等函数以打通接口；用 `templates/tb_template.cpp` 编写测试台；由 `scripts/headless_csim_csynth.tcl` 运行 csim 与 csynth；再用 `scripts/extract_qor.py` 提取资源数据。过程中出现的报错按 `pitfalls/` 检索。

**路径 B：综合停滞或仿真结果不符**

按 `pitfalls/README.md` 的症状索引表检索，第二列为可观察到的工具输出，以日志或报告中的原文比对。无法定位时，参照 `pynq_guide/01` 第六节的处置顺序。

**路径 C：撰写报告或核对数据**

先用 `prompts/p4_data_caliber_audit.md` 将全文数字按"HLS 估算 / 系统实测 / 软件计时"三栏归类，再用 `pynq_guide/04_timing_and_data_caliber.md` 核对 WNS 与频率的对应关系，最后以 `templates/csynth_data_template.md` 统一摘录格式。

---

## 七、范围界定

本包覆盖 **IP 边界以内**的内容：设计方法、验证方法、报告判读、对外接口约定。

边界以外（具体板卡的 block design、约束、实现报告、烧板脚本）属工程交付物，随工程提供。此类内容与具体板卡绑定，纳入本包将破坏通用性。

需要将 IP 接入具体板卡时，参阅 `integration/`：该章提供方法（六条要求、地址反查、口径区分），配合工程自身的 `.hwh` 即可套用。

---

## 八、阅读优先级

若仅需阅读一章，建议优先阅读 `pynq_guide/04_timing_and_data_caliber.md`。

该章说明四类频率概念的差异，以及估计值与实测值不可相减的原因。这两点是返工的主要来源，也是数据被质疑时最常涉及的环节。
