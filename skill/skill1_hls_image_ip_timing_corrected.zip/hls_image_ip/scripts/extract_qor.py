#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
scripts / extract_qor.py

用途
    从 Vitis HLS 的 csynth.rpt（及其子模块报告）中提取关键 QoR 指标，
    输出为 CSV，用于横向对比修改前后的结果。

提取项
    器件、目标周期、估计周期、BRAM_18K、DSP、FF、LUT、Latency(min/max)、Interval

用法
    python extract_qor.py 报告目录 [更多报告目录 ...] -o qor.csv
    python extract_qor.py <报告目录> -o _out/qor.csv
    python extract_qor.py a/csynth.rpt b/csynth.rpt -o qor.csv      # 亦可直接指定文件

设计动机
    单个工程通常含 19 个子报告，逐一打开对比效率低且易读错行。
    本脚本将总表与各子模块汇总为一张表，每次修改代码后运行一次，diff 即可定位变化项。

适用边界
    报告格式随 HLS 版本变化。字段无法解析时，脚本会输出 [未匹配] 并列出前 5 行原文，
    不返回静默空值——静默空值的风险高于显式报错。
"""

import argparse
import csv
import os
import re
import sys

# ---- 报告里的字段正则 ----
RE_DEVICE = re.compile(r"Target device:\s*(\S+)")
RE_DATE = re.compile(r"Date:\s*(.+?)\s*$")
RE_VERSION = re.compile(r"Version:\s*(\S+)")
RE_SOLUTION = re.compile(r"Solution:\s*(.+?)\s*$")

# 时钟表：|ap_clk  |  10.00 ns|  7.300 ns|     1.35 ns|
RE_CLOCK = re.compile(
    r"\|\s*([\w\[\]\.]+)\s*\|\s*([\d.]+)\s*ns\s*\|\s*([\d.]+)\s*ns\s*\|"
)

# 资源总表 Total 行：|Total  |  13|  10|  5109|  7392|  -|
RE_TOTAL = re.compile(
    r"^\s*\|\s*Total\s*\|\s*([\d\-]+)\s*\|\s*([\d\-]+)\s*\|\s*([\d\-]+)\s*\|\s*([\d\-]+)\s*\|\s*([\d\-]+)\s*\|",
    re.M,
)

# 顶层模块行（Performance & Resource Estimates 表）：
# |+ dehaze*  |  -|  0.00|  934980|  9.350e+06|  -|  934975|  -|  dataflow|  13 (4%)|...
RE_TOP_ROW = re.compile(
    r"^\s*\|\+\s*([\w]+)\*?\s*\|[^|]*\|[^|]*\|\s*([\d]+)\s*\|[^|]*\|[^|]*\|\s*([\d]+)\s*\|",
    re.M,
)

# Latency 汇总段（[min, max] 与 dataflow 类型）
RE_LATENCY_BLOCK = re.compile(
    r"Latency\s*\(cycles\)\s*\|?.*?\n.*?\|?\s*([\d]+)\s*\|\s*([\d]+)\s*\|\s*(\w+)", re.S
)


def num(s):
    """将 '13' / '-' / '13 (4%)' 统一转换为 int 或 None。"""
    if s is None:
        return None
    s = s.strip()
    if s in ("-", "", "NA"):
        return None
    m = re.match(r"(\d+)", s)
    return int(m.group(1)) if m else None


def parse_report(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        body = f.read()

    row = {
        "file": os.path.basename(path),
        "module": os.path.splitext(os.path.basename(path))[0].replace("_csynth", ""),
        "date": None,
        "version": None,
        "device": None,
        "target_ns": None,
        "estimated_ns": None,
        "bram": None,
        "dsp": None,
        "ff": None,
        "lut": None,
        "lat_min": None,
        "lat_max": None,
        "interval": None,
        "note": "",
    }

    if m := RE_DATE.search(body):
        row["date"] = m.group(1)
    if m := RE_VERSION.search(body):
        row["version"] = m.group(1)
    if m := RE_DEVICE.search(body):
        row["device"] = m.group(1)

    # 时钟：取第一条匹配（默认时钟）
    if m := RE_CLOCK.search(body):
        row["target_ns"] = float(m.group(2))
        row["estimated_ns"] = float(m.group(3))

    # 资源总表（优先）
    if m := RE_TOTAL.search(body):
        row["bram"], row["dsp"], row["ff"], row["lut"] = (num(m.group(i)) for i in range(1, 5))
    else:
        # 备选路径：部分报告（如顶层 csynth.rpt）没有 Total 行，
        # 只能从模块行的 "13 (4%)" 百分比单元格中取值。
        # 说明：两处数值可能相差数个（本工程为 7392 与 7388），
        # 原因是 Total 行对共享逻辑的计数方式不同，不属错误。
        if m := RE_TOP_ROW.search(body):
            line = body[m.start(): body.find("\n", m.start())]
            pcts = re.findall(r"(\d+)\s*\(\d+%\)", line)
            if len(pcts) >= 4:
                row["bram"], row["dsp"], row["ff"], row["lut"] = (int(x) for x in pcts[:4])
                row["note"] = "资源取自模块行百分比（非 Total 行）"

    # 顶层模块行：max latency 与 interval
    if m := RE_TOP_ROW.search(body):
        row["lat_max"] = num(m.group(2))
        row["interval"] = num(m.group(3))

    # Latency 段：补 min / 类型
    if m := RE_LATENCY_BLOCK.search(body):
        row["lat_min"] = num(m.group(1))
        if row["lat_max"] is None:
            row["lat_max"] = num(m.group(2))

    missing = [k for k in ("device", "bram", "lut", "lat_max") if row[k] is None]
    if missing:
        row["note"] = "未匹配: " + ",".join(missing)
    return row


def collect(paths):
    files = []
    for p in paths:
        if os.path.isdir(p):
            for name in sorted(os.listdir(p)):
                if name.endswith(".rpt"):
                    files.append(os.path.join(p, name))
        elif os.path.isfile(p):
            files.append(p)
        else:
            print(f"[跳过] 不存在: {p}", file=sys.stderr)
    return files


def main():
    ap = argparse.ArgumentParser(description="从 csynth.rpt 提取 QoR 指标")
    ap.add_argument("paths", nargs="+", help="报告目录或 .rpt 文件")
    ap.add_argument("-o", "--out", default="qor.csv", help="输出 CSV（默认 qor.csv）")
    args = ap.parse_args()

    files = collect(args.paths)
    if not files:
        print("没有找到 .rpt 文件", file=sys.stderr)
        return 1

    rows = [parse_report(f) for f in files]

    # 顶层报告排在最前（模块名最短，非子模块）
    rows.sort(key=lambda r: (len(r["module"]), r["module"]))

    cols = ["module", "device", "target_ns", "estimated_ns", "bram", "dsp",
            "ff", "lut", "lat_min", "lat_max", "interval", "date", "version", "note"]

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)

    # 控制台汇总
    print(f"{'module':38s} {'BRAM':>5s} {'DSP':>4s} {'FF':>6s} {'LUT':>6s} {'lat_max':>9s} {'note'}")
    print("-" * 92)
    for r in rows:
        fmt = lambda v: "-" if v is None else str(v)
        print(f"{r['module'][:38]:38s} {fmt(r['bram']):>5s} {fmt(r['dsp']):>4s} "
              f"{fmt(r['ff']):>6s} {fmt(r['lut']):>6s} {fmt(r['lat_max']):>9s} {r['note']}")

    bad = [r for r in rows if r["note"]]
    if bad:
        print(f"\n[注意] {len(bad)} 份报告存在字段未匹配，格式可能已变动，须核对: "
              + ", ".join(r["file"] for r in bad[:5]))
    print(f"\n已写入 {args.out}（{len(rows)} 行）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
