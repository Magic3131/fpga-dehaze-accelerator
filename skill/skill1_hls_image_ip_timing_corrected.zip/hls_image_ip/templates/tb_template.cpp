// ============================================================================
//  02 案例模板 / tb_template.cpp
//
//  全帧逐像素比对测试台，适用于任何"输入一帧、输出一帧"的流式 IP。
//
//  判定标准（四项全部满足方为通过）：
//    1. 输出像素数 == 输入像素数 == WIDTH*HEIGHT
//    2. 帧首 TUSER 恰好出现 1 次，且位于输出第 1 个像素
//    3. 行尾 TLAST 恰好出现 HEIGHT 次
//    4. 每个像素与参考实现逐位相等（不接受近似判定）
//
//  必须包含的极端用例（缺任一项则该类缺陷不可检出）：
//    全 0        —— 检出上溢与除零
//    全 255      —— 检出无符号下溢（见 K05）
//    单点 255    —— 检出窗口对齐偏移（见 K03）
//    自然图、合成雾图 —— 检出整体效果偏差
//
//  用法：
//    在 Vitis HLS 中直接运行 C Simulation；或以 g++ 单独编译（需提供 ap_int 头文件路径）
//    参考实现置于 reference_model()，须与被测代码**独立实现**：
//    直接调用被测函数会使测试台失去比对意义。
// ============================================================================

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cmath>

#include "kernel_skeleton.hpp"     // 替换为自有头文件

// ---------------------------------------------------------------------------
//  测试图生成
// ---------------------------------------------------------------------------
enum Pattern { P_ZERO, P_WHITE, P_SINGLE_DOT, P_GRADIENT, P_FAKE_HAZE, P_RANDOM };

static const char* pattern_name(Pattern p) {
    switch (p) {
        case P_ZERO:       return "all_zero";
        case P_WHITE:      return "all_white";
        case P_SINGLE_DOT: return "single_dot";
        case P_GRADIENT:   return "gradient";
        case P_FAKE_HAZE:  return "fake_haze";
        default:           return "random";
    }
}

static void make_image(Pattern p, std::vector<unsigned>& img, int w, int h, unsigned seed = 12345) {
    img.assign((size_t)w * h, 0u);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            unsigned v = 0;
            switch (p) {
                case P_ZERO:       v = 0x000000; break;
                case P_WHITE:      v = 0xFFFFFF; break;
                case P_SINGLE_DOT: v = (x == w / 2 && y == h / 2) ? 0xFFFFFF : 0x000000; break;
                case P_GRADIENT: {
                    unsigned r = (unsigned)(255 * x / (w > 1 ? w - 1 : 1));
                    unsigned g = (unsigned)(255 * y / (h > 1 ? h - 1 : 1));
                    v = (r << 16) | (g << 8) | ((r + g) / 2);
                    break;
                }
                case P_FAKE_HAZE: {
                    // 模拟雾图：远处整体偏亮、对比度低，中心叠一个暗物体
                    unsigned base = 190 + (unsigned)(15.0 * std::sin(x * 0.01));
                    int dx = x - w / 2, dy = y - h / 2;
                    bool obj = (dx * dx + dy * dy) < (w / 8) * (w / 8);
                    unsigned l = obj ? 60 : base;
                    v = (l << 16) | (l << 8) | l;
                    break;
                }
                default: {
                    seed = seed * 1103515245u + 12345u;
                    v = (seed >> 8) & 0xFFFFFF;
                    break;
                }
            }
            img[(size_t)y * w + x] = v;
        }
    }
}

// ---------------------------------------------------------------------------
//  参考实现（须独立编写，不得调用被测函数）
//  此处为恒等版本，用于验证骨架；替换为自有算法
// ---------------------------------------------------------------------------
static unsigned reference_model(unsigned rgb) {
    return rgb & 0xFFFFFF;          // 恒等
}

// ---------------------------------------------------------------------------
//  跑一帧
// ---------------------------------------------------------------------------
struct Result {
    int    in_px, out_px, user_cnt, last_cnt, mismatch;
    int    first_bad_idx;
    unsigned first_bad_exp, first_bad_got;
    long long cycles;
};

static Result run_one(Pattern pat, int w, int h, bool verbose) {
    std::vector<unsigned> src;
    make_image(pat, src, w, h);

    hls::stream<axis_pix_t> in_s("in_s"), out_s("out_s");

    Result r;
    memset(&r, 0, sizeof(r));
    r.first_bad_idx = -1;

    // ---- 1. 写入输入 ----
    // 说明：此方式成立的前提是 C 仿真中 hls::stream 深度无限。
    // 在 cosim（真实 RTL）中须依靠 DATAFLOW 与 FIFO 深度支撑，否则会死锁。
    // 因此 csim 通过仅说明算法正确，数据流贯通性须由 cosim 验证。
    for (int i = 0; i < w * h; ++i) {
        axis_pix_t p;
        p.data = src[i];
        p.user = (i == 0);
        p.last = ((i % w) == w - 1);
        p.keep = -1;
        in_s.write(p);
        r.in_px++;
    }

    // ---- 2. 调用被测内核 ----
    kernel_top(in_s, out_s);

    // ---- 3. 收输出并逐像素比对 ----
    while (!out_s.empty()) {
        axis_pix_t q = out_s.read();
        r.out_px++;
        if (q.user) r.user_cnt++;
        if (q.last) r.last_cnt++;

        size_t idx = (size_t)(r.out_px - 1);
        if (idx < (size_t)w * h) {
            unsigned exp = reference_model(src[idx]);
            if ((q.data & 0xFFFFFF) != exp) {
                if (r.mismatch == 0) {
                    r.first_bad_idx = (int)idx;
                    r.first_bad_exp = exp;
                    r.first_bad_got = q.data & 0xFFFFFF;
                }
                r.mismatch++;
            }
        }
    }

    if (verbose) {
        printf("  [%s] in=%d out=%d user=%d last=%d(expected %d) mismatch=%d\n",
               pattern_name(pat), r.in_px, r.out_px, r.user_cnt, r.last_cnt,
               (r.out_px > 0 ? 1 : 0), r.mismatch);
        if (r.mismatch) {
            printf("        首个失配 idx=%d (x=%d,y=%d) exp=0x%06X got=0x%06X\n",
                   r.first_bad_idx, r.first_bad_idx % w, r.first_bad_idx / w,
                   r.first_bad_exp, r.first_bad_got);
        }
    }
    return r;
}

// ---------------------------------------------------------------------------
//  main：运行全部用例，任一未通过即返回 1
// ---------------------------------------------------------------------------
int main(int argc, char** argv) {
    // 快速回归：main(64, 48) 或命令行传参
    int w = (argc > 1) ? atoi(argv[1]) : IMG_WIDTH;
    int h = (argc > 2) ? atoi(argv[2]) : IMG_HEIGHT;

    printf("=== 全帧比对测试台 %dx%d ===\n", w, h);

    Pattern cases[] = { P_ZERO, P_WHITE, P_SINGLE_DOT, P_GRADIENT, P_FAKE_HAZE, P_RANDOM };
    const int N = sizeof(cases) / sizeof(cases[0]);
    int pass = 0;

    for (int i = 0; i < N; ++i) {
        Result r = run_one(cases[i], w, h, true);
        bool ok = (r.in_px == r.out_px)
               && (r.out_px == w * h)
               && (r.user_cnt == 1)
               && (r.last_cnt == h)
               && (r.mismatch == 0);
        printf("  -> %s\n", ok ? "PASS" : "FAIL");
        if (ok) pass++;
    }

    printf("\n%d/%d PASS\n", pass, N);
    return (pass == N) ? 0 : 1;
}

// ============================================================================
//  编写测试台时的四类常见缺陷
//    1. 假设"csim 首先写满一帧"在 cosim 中同样成立 —— RTL 的 FIFO 深度有限，会导致死锁。
//       本模板的写法仅在 C 仿真成立，因此 csim 通过后须再运行 cosim。
//    2. 参考实现直接调用被测函数 —— 比对失去意义。
//    3. 仅测试自然图 —— 边界、纯色、单点三类用例才能暴露 K03/K05 所述缺陷。
//    4. 未检查 TUSER/TLAST —— 缺少一个像素不会报错，仅导致画面斜切（K07）。
// ============================================================================
