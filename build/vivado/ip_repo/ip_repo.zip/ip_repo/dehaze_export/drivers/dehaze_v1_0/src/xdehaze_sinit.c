// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xdehaze.h"

extern XDehaze_Config XDehaze_ConfigTable[];

XDehaze_Config *XDehaze_LookupConfig(u16 DeviceId) {
	XDehaze_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDEHAZE_NUM_INSTANCES; Index++) {
		if (XDehaze_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDehaze_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDehaze_Initialize(XDehaze *InstancePtr, u16 DeviceId) {
	XDehaze_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDehaze_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDehaze_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

