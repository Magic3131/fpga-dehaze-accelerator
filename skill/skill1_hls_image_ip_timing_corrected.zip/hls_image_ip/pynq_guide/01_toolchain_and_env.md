# 05-01｜工具链与环境

> 通用性：与题目无关，适用于任何图像 IP 与 Zynq 板卡；唯一绑定的对象是 Vitis HLS 工具链。

## 一、路径交由环境变量管理

不应将 `D:/Vitis_HLS/2022.2` 直接写入脚本，应增加一层间接引用：

```batch
:: set_hls_env.bat —— 更换机器时仅需修改此行
set HLS_ROOT_ENV=D:\Vitis_HLS\2022.2
set PATH=%HLS_ROOT_ENV%\lib\win64.o;%HLS_ROOT_ENV%\bin;%PATH%
```

| 子路径 | 内容 | 用途 |
|---|---|---|
| `bin\vitis_hls.bat` | 命令行入口 | 无头运行 csim/csynth |
| `win64\tools\clang-3.9-csynth\bin\clang++.exe` | 综合前端所用的 clang | 秒级语法检查 |
| `lib\win64.o` | 运行时 DLL | 未加入 PATH 时报 `libsqlite3.28.0.dll not found` |
| `tps\win64\msys64\mingw64` | mingw 工具链 | **不用于编译**，原因见下 |
| `include` + `common\technology\autopilot` | `ap_int.h`、`hls_stream.h` | 语法检查的 include 路径 |

## 二、四类环境问题

| 问题 | 现象 | 处置 |
|---|---|---|
| mingw 的 `g++.exe` 静默失败 | 编译任何文件均 exit 1 且无输出，`g++ -v` 亦然 | 不在此项上排查，改用 csynth 的 clang，或安装独立 MinGW-w64 |
| 缺少 DLL 目录 | 启动即报 `libsqlite3.28.0.dll not found` | 将 `lib\win64.o` 加入 PATH |
| 日志编码为 GBK | 命令行中中文显示为乱码 | `iconv -f GBK -t UTF-8 run.log`，或使用支持 GBK 的编辑器 |
| 批处理中包含中文 | `.bat` 中出现全角括号或中文时，`cmd.exe` 将括号解析为命令分隔符，脚本失效（本工程经验：改为纯 ASCII 后方可运行） | 脚本内容一律使用 ASCII，中文说明放置于 README |

## 三、秒级语法检查（不启动 GUI）

修改一行代码后确认语法，无需等待约 40 秒的综合：

```bash
C39="$HLS_ROOT/win64/tools/clang-3.9-csynth/bin/clang++.exe"
M="$HLS_ROOT/tps/win64/msys64/mingw64"
"$C39" -std=c++14 -fsyntax-only -Wno-unknown-pragmas -w \
  -target x86_64-w64-mingw32 \
  -isystem "$HLS_ROOT/include" \
  -isystem "$HLS_ROOT/common/technology/autopilot" \
  -isystem "$M/include/c++/6.2.0" \
  -isystem "$M/include/c++/6.2.0/x86_64-w64-mingw32" \
  -isystem "$M/x86_64-w64-mingw32/include" -isystem "$M/include" \
  your_kernel.cpp
# EXIT=0 且无输出即为通过
```

`win64/tools/clang/bin`（clang 3.1）版本过旧，会对自带的 libstdc++ 头文件报大量错误，不予使用。

## 四、无头运行 csim 与 csynth

**须另建目录**，不可与 GUI 已打开的工程同名，否则会发生工程锁冲突。

```bash
cd /path/_verify
"$HLS_ROOT/bin/vitis_hls.bat" run.tcl > run.log 2>&1
```

tcl 中的顺序不可调整（调整后本次运行无效）：

```tcl
open_project prj
set_top your_top
add_files kernel.cpp
add_files -tb kernel_test.cpp -cflags "-Wno-unknown-pragmas" -csimflags "-Wno-unknown-pragmas"
open_solution "sol1" -flow_target vivado   ;# ① 必须带 flow_target，否则接口打包方式改变
set_part {xc7z020-clg400-1}                ;# ② 必须在 open_solution 之后
create_clock -period 10 -name default      ;# ③ 必须在 csynth 之前
csim_design -quiet
csynth_design
```

可直接使用 `scripts/headless_csim_csynth.tcl`，上述顺序已固化其中。

## 五、各步骤耗时（720p 规模）

| 步骤 | 耗时 | 是否可省略 |
|---|---|---|
| `csim_design` | 约 220 秒（16 个用例，720p） | 不可省略，每次修改代码后均需运行 |
| `csynth_design` | 约 53 秒 | 不可省略，为唯一提供资源与时序估计的步骤 |
| `cosim_design` | **约 40 分钟**（16 个事务逐拍运行 XSIM） | 不可省略；可缩至 64×48 分辨率压缩到约 2 分钟，用于回归 |
| `export_design` | 约 10 秒 | — |

**缩分辨率回归的代价**：修改宏、重跑全流程、再改回。改回后须重新执行完整流程，否则报告对应的是 64×48 配置。详见 `scripts/headless_csim_csynth.tcl` 末尾说明。

## 六、综合停滞时的处置顺序

日志停在 `INFO: [HLS 200-777] Using interface defaults for 'Vivado' flow target.` 且数小时无进展：

1. 确认 `200-777` 为**每次运行都会输出的常规 INFO**，不是错误本身
2. 按代价由低到高减少 pragma：`BIND_STORAGE` → 大数组 `ARRAY_PARTITION` → 顺序循环 `PIPELINE`
3. 更根本的路径：将动态索引改为静态结构（`row & 1` 双数组），索引静态化后再加回显式绑定通常正常
4. 反复新建 solution 或重启软件不产生效果
5. 该问题属 2022.2 已知缺陷，2023.1 修复

详见 `pitfalls/k01_csynth_hang_200_777.md`。

## 七、交叉验证

| 需确认的事项 | 查看位置 |
|---|---|
| 循环是否实际达到 II=1 | 日志 `Target II = 1, Final II = 1`；报告 `Pipelined` 列 |
| 并行是否生效 | 报告 `Latency Type` 是否为 `dataflow` |
| 存储推断结果 | 日志 `Implementing memory 'xxx' using block RAMs` |
| 报告是否对应本次源码 | `scripts/loop_id_consistency.py` |
