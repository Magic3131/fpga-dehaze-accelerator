# scripts｜校验脚本

## 目标

在没有校验脚本的情况下，"IP 实现正确"这一结论只能依赖手工截图与目视比对。本目录的四个脚本将其转化为三项可重复的操作：**环境一致、数据可提取、编号可核对。**

| 脚本 | 功能 | 运行时机 | 实测效果 | 适用边界 |
|---|---|---|---|---|
| `hls_env_check.bat` | 检查 Vitis HLS 路径、clang、DLL 是否可用 | 更换机器后、每次开始工作前 | 一次定位到"mingw g++ 静默失败"与"DLL 找不到"两类环境问题 | 面向 Windows 批处理；Linux 下将 `where` 换为 `which`、`;` 换为 `:`，判断逻辑无需修改 |
| `headless_csim_csynth.tcl` | 不启动 GUI，以命令行运行 csim + csynth（分辨率可缩小） | 每次修改代码后 | 720p 全流程约 2 分 40 秒，不干扰 GUI 工程锁 | 需 `vitis_hls.bat` 可用；工程目录不得与 GUI 已打开的工程同名 |
| `extract_qor.py` | 从 `csynth.rpt` 提取 LUT/FF/BRAM/DSP/Latency/时钟，输出 CSV | 综合完成后、成文前 | 将多份报告的横向对比由逐一翻阅 19 份文件变为一张表 | 报告格式随 HLS 版本变化，解析失败时明确报出未匹配字段 |
| `loop_id_consistency.py` | 核对源码行号与报告中的 `VITIS_LOOP_xxx` 编号 | 修改代码后、签核前 | 一次检出"报告非当前源码生成"这类严重错误 | 仅覆盖带 `#pragma HLS LOOP` 或位于函数体内可识别的循环 |

---

## 一、运行条件

本文所附运行记录均来自同一环境：

| 项 | 值 |
|---|---|
| 工具版本 | Vitis HLS 2022.2（Windows 版） |
| 操作系统 | Windows 10，`cmd.exe` |
| 被处理的设计 | 4 个源文件、顶层 `dehaze`、720p、16 个 csim 用例 |
| 未验证范围 | Vitis HLS 2023.x、Linux、macOS、其他顶层函数 |

更换环境后脚本仍可使用，但**上表中的耗时与资源数据不再成立**，须按本机运行结果重新记录。

---

## 二、路径约定

脚本中出现的路径分三类，用途不同：

| 类型 | 出现位置 | 性质 | 替换方式 |
|---|---|---|---|
| 工具安装路径 | `hls_env_check.bat` 的默认值 `D:\Vitis_HLS\2022.2`；`headless_csim_csynth.tcl` 文件头注释 | **示例值**，仅用于说明命令形式 | 以第一个参数传入（`hls_env_check.bat "E:\Xilinx\Vitis_HLS\2022.2"`），或设置环境变量 `HLS_ROOT_ENV`，无需修改脚本 |
| 工程与源码路径 | 各脚本文件头的 `python xxx.py <路径>`、`"%HLS%" -f ... <源码目录>` | **示例值** | 运行时作为命令行参数传入；脚本不依赖任何固定目录 |
| 输出目录 | `-o _out/qor.csv` | 建议值 | 可改为任意路径；`_out` 便于整体删除 |

三条使用规则：

1. **无需为运行而修改脚本内部的路径常量**——需变更的内容均以参数传入。
2. 源码或工程路径**不应包含中文**，否则 `csim` 的 `make` 阶段会失败（脚本已做 ASCII 暂存中转，工程目录仍建议避开）。
3. 运行记录中的 `C:/Users/...` 为运行现场路径，属记录内容，不构成脚本要求的目录结构。

---

## 三、结果记录（一次运行的原样输出，供对照）

**`extract_qor.py` 对 19 份综合报告**（报告目录由参数给出）：

```
module                                  BRAM  DSP     FF    LUT   lat_max note
csynth                                    13   10   5109   7392    934980 资源取自模块行百分比（非 Total 行）
dehaze                                    13   10   5109   7388    934980
sobel_core                                 5    2   1579   2513    934974
dark_window                                6    0   1022   1158    923608
dehaze_core                                8    8   2626   3698    923609
restore_stream                             2    8   1172   2132    921645
...
已写入 _out/qor.csv（19 行）
```

**由此暴露一处口径问题**：`csynth` 与 `dehaze` 为同一设计的两种视图，LUT 分别为 7392 与 7388。
不属错误——Total 行与模块行对共享逻辑的计数方式不同。但**成文时须选定一个**（见 `templates/csynth_data_template.md` 第六节）。

**`loop_id_consistency.py` 对 `dehaze.cpp` 与报告目录**：

```
源码 : dehaze.cpp  (386 行, 18 个循环)
报告 : 20 个文件, 23 个循环编号
[一致] 14 处
[失配] 9 处 —— 全部出自 csynth 运行日志
[具名] 2 处 —— WINDOW_BYPASS / RESTORE_BYPASS（报告里以 Pipeline_<标签> 出现）
[未覆盖] 1 处 —— WINDOW_COLS（嵌在 WINDOW_ROWS 内，被合并命名）

结论：9 处失配全部来自 .log。
      报告本身无误，日志中混有旧版本运行的循环编号（见 K10）。
      引用数字仅使用 .rpt；日志用于查历史，不可作为证据。
```

本次运行实际复现了 `pitfalls/k10_csynth_log_mixed_runs.md` 所述问题：日志中出现 `LOOP_423_1`、`LOOP_430_2` 等编号，而当前源码仅 386 行，说明日志混有更长版本的旧运行记录。脚本按 `.rpt` 与 `.log` 分别判读，避免误报为"报告过期"。

**`headless_csim_csynth.tcl` 无头运行完整流程**（源码目录与顶层名由参数给出）：

```
SRC  : <源码目录>
TOP  : dehaze
MODE : full
WORK : %TEMP%\hls_verify            <- 自动避开非 ASCII 路径
============================================================
staged 4 file(s)
>>> csim_design
[PASS] raw_bypass                     pixels=921600 SOF/EOL OK
[PASS] dehaze_default_parameters      pixels=921600 SOF/EOL OK
...
csim done in 217 s
>>> csynth_design
INFO: [HLS 200-790] **** Loop Constraint Status: All loop constraints were satisfied.
INFO: [HLS 200-789] **** Estimated Fmax: 136.99 MHz
csynth done in 53 s
xc7z020-clg400-1
UTIL: |Total            |       13|   10|    5109|   7388|    0|
```

**该脚本在开发中遇到并已处理的三类问题**（见文件头注释）：

1. `vitis_hls` 会将 `-f` 与脚本名一并放入 `argv`，直接取 `argv[0]` 得到的是 `"-f"`
2. 工程目录含中文 → `open_solution` 在 `set_msg_logfile` 处报错退出
3. **源码**路径含中文 → csim 的 `make` 无法识别路径，报 `No such file or directory`

处置方式：先过滤参数；工程目录检测到非 ASCII 时退至 `%TEMP%`；源码先复制到 ASCII 暂存目录再 `add_files`。

> 第 3 项与"中文路径是否可用"无关，**仅影响 csim 的 make 阶段**，综合阶段正常。此现象易被误判为编码环境变量问题，实际更换目录即可解决。

---

## 四、执行顺序

```
1. hls_env_check.bat              ← 环境不正确时，后续步骤均无效
2. headless_csim_csynth.tcl       ← 生成报告
3. loop_id_consistency.py         ← 确认报告对应当前源码
4. extract_qor.py                 ← 提取为表格，成文时直接引用
```

第 3 步最易被跳过，风险也最高：**引用旧代码生成的报告时，全部数值失效**。

---

## 五、通用约定

- 工具链位置通过环境变量 `HLS_ROOT_ENV`（或第一个命令行参数）给出；脚本内不硬编码安装路径
- 脚本不修改任何源文件（`headless_csim_csynth.tcl` 的缩分辨率模式除外，其运行结束后自动还原，见脚本内说明）
- 建议以 `-o _out/qor.csv` 将输出集中至一处，运行结束后删除 `_out` 即完成清理；本目录的 `results/` 即按此方式生成
- `results/qor.csv` 与 `results/headless_csim_csynth_run.log` 为**一次运行的原样记录**，用于对照格式，不作为当前环境的基准

---

## 六、适用范围与已知边界

四个脚本在 Vitis HLS 2022.2 与 Windows 10 上按第一节条件运行过；其他版本与平台未经验证，按下表判断：

| 场景 | 表现 | 处理方式 |
|---|---|---|
| Vitis HLS 2023.x 及以后 | `extract_qor.py` 的正则按 2022.2 的表格列顺序编写，列序变化时解析失败并明确报出未匹配字段 | 将 `csynth.rpt` 的资源表头与 `extract_qor.py` 中 `RE_TOTAL` 一行比对，修改一条正则即可 |
| Linux / macOS | `.bat` 不能直接运行；`.tcl` 与 `.py` 跨平台 | 环境检查修改三处：`where`→`which`、`;`→`:`、`vitis_hls.bat`→`vitis_hls` |
| 工程规模较大（报告超过 10 万行） | 解析仍可用，CSV 行数较多 | 将参数由"整个目录"改为单个 `.rpt` 文件路径 |
| 报告为 `-csim` 或 `cosim` 而非 `csynth` | 资源表不存在 | 本脚本仅针对 `csynth` 报告；cosim 仅关注事务表一节 |
