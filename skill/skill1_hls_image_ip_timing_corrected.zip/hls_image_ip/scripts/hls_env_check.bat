@echo off
rem ============================================================
rem  scripts / hls_env_check.bat   (ASCII only -- see note at bottom)
rem  Purpose : verify the Vitis HLS toolchain (about 10 seconds)
rem  Usage   : hls_env_check.bat [HLS_INSTALL_DIR]
rem            or set env var HLS_ROOT_ENV before running.
rem            The fallback D:\Vitis_HLS\2022.2 is an example value only,
rem            not a requirement -- override it with the arg or the env var.
rem  Exit    : 0 = ok, 1 = critical item missing
rem ============================================================
setlocal EnableDelayedExpansion

set "FAIL=0"
set "HLS_ROOT=%~1"
if "%HLS_ROOT%"=="" set "HLS_ROOT=%HLS_ROOT_ENV%"
if "%HLS_ROOT%"=="" set "HLS_ROOT=D:\Vitis_HLS\2022.2"

echo.
echo ============================================================
echo  Vitis HLS environment check
echo  HLS_ROOT = %HLS_ROOT%
echo ============================================================
echo.

if exist "%HLS_ROOT%\bin\vitis_hls.bat" (
    echo [ OK ] bin\vitis_hls.bat
) else (
    echo [FAIL] missing %HLS_ROOT%\bin\vitis_hls.bat
    echo        pass the install dir as 1st arg, or set HLS_ROOT_ENV
    set "FAIL=1"
)

if exist "%HLS_ROOT%\VERSION" (
    set /p VER=<"%HLS_ROOT%\VERSION"
    echo [ OK ] version !VER!
)

if exist "%HLS_ROOT%\win64\tools\clang-3.9-csynth\bin\clang++.exe" (
    echo [ OK ] clang-3.9-csynth ^(fast syntax check^)
) else (
    echo [WARN] clang-3.9-csynth missing - syntax check unavailable
)

if exist "%HLS_ROOT%\lib\win64.o" (
    echo [ OK ] lib\win64.o  ^(DLL dir^)
) else (
    echo [FAIL] lib\win64.o missing - will hit libsqlite3.28.0.dll not found
    set "FAIL=1"
)

if exist "%HLS_ROOT%\tps\win64\msys64\mingw64\bin\g++.exe" (
    echo [WARN] mingw g++.exe found - fails silently; not recommended for compilation
) else (
    echo [INFO] no mingw g++ found (not required)
)

where python >nul 2>nul
if errorlevel 1 (
    echo [WARN] python not in PATH - extract_qor.py / loop_id_consistency.py will not run
) else (
    for /f "delims=" %%V in ('python -c "import sys;print(sys.version.split()[0])" 2^>nul') do echo [ OK ] python %%V
)

echo.
echo ============================================================
if "%FAIL%"=="1" (
    echo  RESULT: critical items missing; resolve environment issues first
    echo ============================================================
    endlocal & exit /b 1
)
echo  RESULT: core items present
echo  NEXT  : headless_csim_csynth.tcl
echo ============================================================
endlocal & exit /b 0

rem ============================================================
rem  NOTE: this file is ASCII-only on purpose.
rem  Chinese characters (especially full-width parentheses) inside
rem  a .bat file break cmd.exe parsing under either codepage.
rem  If you must localize the messages, use English, or move the
rem  text into README.md instead of the script.
rem ============================================================
